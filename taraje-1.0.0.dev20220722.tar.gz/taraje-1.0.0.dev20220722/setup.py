# -*- coding: utf-8 -*-
from __future__ import absolute_import

import atexit
import sys
import re

from pathlib import Path

try:
    from setuptools import setup, find_packages, Extension
    from setuptools.command.build_py import build_py as build_py_orig
except ImportError:
    from distutils.core import setup, find_packages, Extension
    from distutils.command.build_py import build_py as build_py_orig


class build_py(build_py_orig):
    def find_package_modules(self, package, package_dir):
        paks = []
        modules = super().find_package_modules(package, package_dir)
        for pkg, mod, file in modules:
            if mod == "__init__":
                paks.append((pkg, mod, file))
        return [
            (
                pkg,
                mod,
                file,
            )
            for (
                pkg,
                mod,
                file,
            ) in modules
            if mod == "__init__"
        ]


class _file_opts:
    @staticmethod
    def read(destination):
        path = Path.cwd().joinpath(destination)
        if path.exists():
            return path.read_text()

    @staticmethod
    def write(destination, content):
        path = Path.cwd().joinpath(destination)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)


def _reset_hard_work_tree():
    for f in [*TARAJE.glob(f"**/*.c")]:
        f.unlink()
    print(f"~/{TARAJE.relative_to(Path.home())} has been reverted!")


def dev_status(version):
    if "dev" in version:
        return "Development Status :: 4 - Beta"
    else:
        return "Development Status :: 5 - Production/Stable"


def has_option(name):
    if name in sys.argv[1:]:
        sys.argv.remove(name)
        return True


TARAJE = Path.cwd().joinpath("taraje")
VERSION = (
    re.compile(r"\s.*(:Version:)(?= (?P<version>.*))")
    .search(TARAJE.joinpath("__init__.py").read_text())
    .group("version")
)
extra_setup_args = {}

if "setuptools" in sys.modules:
    extra_setup_args["zip_safe"] = False

# minify packages if requested or necessary
if has_option("--minify"):
    from python_minifier import minify
    candidates = [
        file.relative_to(TARAJE.parent)
        for file in [*TARAJE.glob("**/*.py")]
        if file.stem != "__init__"
    ]
    print("**minifying the package")
    for file in candidates:
        print(f"    {file}")
        minified = minify(
            source=file.read_bytes(),
            filename=file,
            remove_annotations=True,  # default
            remove_pass=True,  # default
            remove_literal_statements=False,  # default
            combine_imports=True,  # default
            hoist_literals=True,  # default
            rename_locals=True,  # default
            preserve_locals=None,  # default
            rename_globals=False,  # default
            preserve_globals=None,  # default
            remove_object_base=True,  # default
            convert_posargs_to_args=True,  # default
            preserve_shebang=True,  # default
        )
        file.write_text(minified)
    print()

# use Cython if requested or necessary
CythonBuild = None
source_extension = "c"
use_cython = has_option("--cythonize")

if not use_cython:
    if not [*TARAJE.glob("**/*.c")]:
        print("**generated sources not available, need Cython to build")
        use_cython = True

if use_cython:
    try:
        import Cython.Compiler.Version as CompilerVersion
        import Cython.Compiler.Errors as CompilerErrors
        import Cython.Compiler.Options as CompilerOptions
        import Cython.Build as CythonBuild

        print(f"**building with Cython {CompilerVersion.version}")
        source_extension = "py"
        CompilerErrors.LEVEL = 0
        CompilerOptions.docstrings = True
    except ImportError:
        print("**WARNING: trying to build with Cython, but it is not installed")
else:
    print("**building without Cython")

ext_modules = [
    Extension(
        source.relative_to(TARAJE.parent)
        .as_posix()
        .rstrip(source.suffix)
        .replace("/", "."),
        sources=[source.relative_to(TARAJE.parent).as_posix()],
    )
    for source in [*TARAJE.glob(f"**/*.{source_extension}")]
    if source.stem != "__init__"
]

if CythonBuild is not None:
    ext_modules = CythonBuild.cythonize(
        ext_modules,
        compiler_directives={
            "language_level": 3,
            "emit_code_comments": False,
            # "c_string_type": "bytes",
            # "c_string_encoding": "utf-8",
        },
    )
    if has_option("--clean"):
        atexit.register(_reset_hard_work_tree)
print()


long_description = "\n\n".join(
    _file_opts.read(Path(text_file)) for text_file in ["README.rst"]
)

# _file_opts.write(
#     Path("taraje", "version.py"), u'__version__ = "%s"\n' % VERSION
# )

print("**calling setup")
setup(
    name="taraje",
    version=VERSION,
    author="ampasmanusa (bancetzLaut)",
    author_email="0.ampasmanusa@gmail.com",
    url="https://t.me/Taraje_dah",
    description="Taraje's Bot Loader",
    long_description=long_description,
    classifiers=[
        dev_status(VERSION),
        "Environment :: Console",
        "Intended Audience :: End Users/Desktop",
        # "Operating System :: Android",
        "Operating System :: POSIX",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3 :: Only",
        "Topic :: Other/Nonlisted Topic",
    ],
    python_requires="~=3.10.0",  # / "==3.10.*" / ">=3.10, <3.11",
    packages=[
        "taraje",
        "taraje.lib",
        "taraje.lib.Limbo",
    ],
    package_data={"taraje": ["_config/*"]},
    ext_modules=ext_modules,
    cmdclass={"build_py": build_py},
    entry_points={
        "console_scripts": ["taraje-lua=taraje.cli:_TarajeCLI"],
    },
    install_requires=[
        "aiohttp",
        "click",
        "colorama",
        "lupa",
        "msgpack",
        "ujson",
    ],
    **extra_setup_args,
)
print()
